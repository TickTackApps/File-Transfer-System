import os
import sys
import time
import socket
import json
import psutil
import threading
import tkinter as tk
from tkinter import filedialog, messagebox
from pathlib import Path
from multiprocessing import Process, Value, Queue
from flask import Flask, request, send_file, jsonify
import winshell
import win32com.client

# ------------------ Flask Server Code ------------------

def run_server(shared_dir, is_running_flag, log_queue):
    app = Flask(__name__)

    if not os.path.exists(shared_dir):
        os.makedirs(shared_dir)

    @app.route('/upload', methods=['POST'])
    def upload_file():
        if 'file' not in request.files:
            return jsonify({"error": "No file part"}), 400
        file = request.files['file']
        if file.filename == '':
            return jsonify({"error": "No selected file"}), 400
        file_path = os.path.join(shared_dir, file.filename)
        file.save(file_path)
        log_queue.put(f"[UPLOAD] {file.filename}")
        return jsonify({"message": "Uploaded", "filename": file.filename}), 200

    @app.route('/download/<filename>', methods=['GET'])
    def download_file(filename):
        file_path = os.path.join(shared_dir, filename)
        if os.path.exists(file_path):
            log_queue.put(f"[DOWNLOAD] {filename}")
            return send_file(file_path, as_attachment=True)
        return jsonify({"error": "File not found"}), 404

    @app.route('/files', methods=['GET'])
    def list_files():
        return jsonify(os.listdir(shared_dir))

    @app.route('/delete/<filename>', methods=['DELETE'])
    def delete_file(filename):
        file_path = os.path.join(shared_dir, filename)
        if os.path.exists(file_path):
            os.remove(file_path)
            log_queue.put(f"[DELETE] {filename}")
            return jsonify({"message": "Deleted"}), 200
        return jsonify({"error": "File not found"}), 404

    class StreamToQueue:
        def __init__(self, queue):
            self.queue = queue
        def write(self, msg):
            if msg.strip():
                self.queue.put(msg)
        def flush(self):
            pass

    sys.stdout = StreamToQueue(log_queue)
    sys.stderr = StreamToQueue(log_queue)

    is_running_flag.value = 1
    try:
        log_queue.put("🔵 Starting Flask server...")
        app.run(host='0.0.0.0', port=5000)
    except Exception as e:
        log_queue.put(f"❌ Error: {str(e)}")
    finally:
        is_running_flag.value = 0
        log_queue.put("🔴 Flask server stopped.")

# ------------------ GUI Code ------------------

class FlaskGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("File Transfer by Tick Tack Apps")
        self.root.geometry("700x600")

        # Load saved or default folder
        self.shared_folder = self.load_saved_folder()
        self.server_process = None
        self.is_running = Value('i', 0)
        self.log_queue = Queue()
        self.user_requested_start = False

        # IP display
        self.local_ip = self.get_local_ip()
        self.ip_label = tk.Label(root, text=f"📡 Your IP: {self.local_ip}", font=("Arial", 11, "bold"))
        self.ip_label.pack(pady=(10, 0))

        # Shared folder label
        self.folder_label = tk.Label(root, text=f"Shared Folder: {self.shared_folder}", wraplength=600, anchor="w", justify="left")
        self.folder_label.pack(pady=5, padx=10, anchor="w")

        # Folder chooser
        self.choose_button = tk.Button(root, text="Choose Folder", command=self.choose_folder)
        self.choose_button.pack(pady=5)

        # Startup toggle
        self.startup_var = tk.BooleanVar()
        self.startup_var.set(self.is_in_startup())

        self.startup_toggle = tk.Checkbutton(
            root, text="Run on Startup", variable=self.startup_var,
            command=self.toggle_startup, font=("Arial", 10)
        )
        self.startup_toggle.pack(pady=(0, 5))

        # Start/Stop
        self.start_button = tk.Button(root, text="Start Server", command=self.start_server)
        self.start_button.pack(pady=5)

        self.stop_button = tk.Button(root, text="Stop Server", command=lambda: self.stop_server(by_wifi=False), state=tk.DISABLED)
        self.stop_button.pack(pady=5)

        # Status label
        self.status_label = tk.Label(root, text="🔴 Server Stopped", fg="red", font=("Arial", 12, "bold"))
        self.status_label.pack(pady=10)

        # Log area
        self.log_text = tk.Text(root, height=20, bg="black", fg="white", insertbackground="white", state=tk.DISABLED)
        self.log_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        self.poll_log_queue()
        threading.Thread(target=self.monitor_wifi, daemon=True).start()
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    # 🧠 Load folder from config
    def load_saved_folder(self):
        try:
            with open("config.json", "r") as f:
                data = json.load(f)
                if os.path.exists(data.get("shared_folder", "")):
                    return data["shared_folder"]
        except:
            pass
        return str(Path.home() / "Downloads")

    # 💾 Save folder to config
    def save_folder(self, path):
        with open("config.json", "w") as f:
            json.dump({"shared_folder": path}, f)

    def choose_folder(self):
        folder = filedialog.askdirectory()
        if folder:
            self.shared_folder = folder
            self.folder_label.config(text=f"Shared Folder: {self.shared_folder}")
            self.save_folder(self.shared_folder)
            messagebox.showinfo("Folder Changed", f"New shared folder:\n{self.shared_folder}")

    def start_server(self):
        if self.server_process is None or not self.server_process.is_alive():
            self.user_requested_start = True
            self.server_process = Process(target=run_server, args=(self.shared_folder, self.is_running, self.log_queue))
            self.server_process.start()
            self.update_status(True)
            self.start_button.config(state=tk.DISABLED)
            self.stop_button.config(state=tk.NORMAL)

    def stop_server(self, by_wifi=False):
        if self.server_process and self.server_process.is_alive():
            self.server_process.terminate()
            self.server_process.join()
        self.server_process = None
        if not by_wifi:
            self.user_requested_start = False
        self.update_status(False)
        self.start_button.config(state=tk.NORMAL)
        self.stop_button.config(state=tk.DISABLED)

    def update_status(self, running):
        if running:
            self.status_label.config(text="🟢 Server Running", fg="green")
        else:
            self.status_label.config(text="🔴 Server Stopped", fg="red")

    def poll_log_queue(self):
        try:
            while True:
                log = self.log_queue.get_nowait()
                self.log_text.config(state=tk.NORMAL)
                self.log_text.insert(tk.END, log + "\n")
                self.log_text.see(tk.END)
                self.log_text.config(state=tk.DISABLED)
        except:
            pass
        self.root.after(100, self.poll_log_queue)

    def monitor_wifi(self):
        wifi_was_connected = None
        while True:
            connected = self.is_wifi_connected()
            if connected != wifi_was_connected:
                wifi_was_connected = connected
                if connected:
                    self.log_queue.put("📶 Wi-Fi connected")
                    self.root.after(0, self.enable_start_stop_buttons)
                    if self.user_requested_start and (not self.server_process or not self.server_process.is_alive()):
                        self.root.after(0, self.start_server)
                    self.root.after(0, lambda: self.update_status(self.server_process is not None and self.server_process.is_alive()))
                else:
                    self.log_queue.put("🚫 Wi-Fi disconnected")
                    self.root.after(0, self.disable_start_stop_buttons)
                    self.root.after(0, lambda: self.stop_server(by_wifi=True))
                    self.root.after(0, lambda: self.status_label.config(text="❌ No Wi-Fi", fg="orange"))
            time.sleep(3)

    def is_wifi_connected(self):
        for iface, addrs in psutil.net_if_addrs().items():
            stats = psutil.net_if_stats().get(iface)
            if stats and stats.isup and ("wi-fi" in iface.lower() or "wlan" in iface.lower() or "wireless" in iface.lower()):
                return True
        return False

    def disable_start_stop_buttons(self):
        self.start_button.config(state=tk.DISABLED)
        self.stop_button.config(state=tk.DISABLED)

    def enable_start_stop_buttons(self):
        if self.server_process and self.server_process.is_alive():
            self.start_button.config(state=tk.DISABLED)
            self.stop_button.config(state=tk.NORMAL)
        else:
            self.start_button.config(state=tk.NORMAL)
            self.stop_button.config(state=tk.DISABLED)

    def on_close(self):
        self.stop_server()
        self.root.destroy()

    def get_local_ip(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except:
            return "Unavailable"

    # ------------------ Startup Toggle Methods ------------------

    def toggle_startup(self):
        if self.startup_var.get():
            self.add_to_startup()
            self.log_queue.put("✅ Added to startup")
        else:
            self.remove_from_startup()
            self.log_queue.put("❌ Removed from startup")

    def get_startup_path(self):
        return os.path.join(winshell.startup(), "File-Transfer-Desktop-Site.lnk")

    def is_in_startup(self):
        return os.path.exists(self.get_startup_path())

    def add_to_startup(self):
        vbs_path = os.path.abspath("File-Transfer-Desktop-Site.vbs")
        shortcut_path = self.get_startup_path()

        shell = win32com.client.Dispatch("WScript.Shell")
        shortcut = shell.CreateShortCut(shortcut_path)
        shortcut.Targetpath = vbs_path
        shortcut.WorkingDirectory = os.path.dirname(vbs_path)
        shortcut.IconLocation = "shell32.dll,1"
        shortcut.save()

    def remove_from_startup(self):
        try:
            os.remove(self.get_startup_path())
        except FileNotFoundError:
            pass

# ------------------ Run GUI ------------------

if __name__ == '__main__':
    root = tk.Tk()
    root.iconbitmap("File-Transfer-Desktop-Site.ico")
    app = FlaskGUI(root)
    root.mainloop()
